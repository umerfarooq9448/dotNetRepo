﻿namespace SecurityMovie.Models
{
    public class UserLogin
    {
        public string userName { get; set; }
        public string userpassword { get; set; }
    }
}
